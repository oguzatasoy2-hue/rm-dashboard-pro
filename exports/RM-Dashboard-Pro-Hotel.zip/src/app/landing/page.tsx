"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
    CheckCircle,
    ArrowRight,
    BarChart3,
    Zap,
    Shield,
    Layers,
    RefreshCw,
    Star,
    Code2,
    ExternalLink,
} from "lucide-react";
import Link from "next/link";

const ease = [0.16, 1, 0.3, 1] as const;

// --- Data ---
const NICHES = [
    {
        key: "hotel",
        label: "🏨 Hotel / Real Estate",
        color: "#EAC54F",
        shadow: "shadow-[0_0_40px_rgba(234,197,79,0.25)]",
        ring: "ring-[#EAC54F]/30",
        badge: "bg-[#EAC54F]/10 text-[#EAC54F] border-[#EAC54F]/20",
        headline: "Revenue Management for Hospitality",
        sub: "Track Occupancy, ADR, RevPAR and market parity in real-time.",
        kpis: ["Occupancy Rate", "ADR (Avg Daily Rate)", "RevPAR", "Rate Parity"],
        command: "npm run theme:hotel",
    },
    {
        key: "saas",
        label: "💻 B2B SaaS Metrics",
        color: "#6366F1",
        shadow: "shadow-[0_0_40px_rgba(99,102,241,0.25)]",
        ring: "ring-[#6366F1]/30",
        badge: "bg-[#6366F1]/10 text-[#6366F1] border-[#6366F1]/20",
        headline: "Revenue Intelligence for SaaS Products",
        sub: "Monitor MRR, Churn Rate, ARPU and traffic conversion effortlessly.",
        kpis: ["MRR Growth", "Churn Rate", "ARPU", "Traffic Conversion"],
        command: "npm run theme:saas",
    },
    {
        key: "ecommerce",
        label: "🛒 E-Commerce & Retail",
        color: "#10B981",
        shadow: "shadow-[0_0_40px_rgba(16,185,129,0.25)]",
        ring: "ring-[#10B981]/30",
        badge: "bg-[#10B981]/10 text-[#10B981] border-[#10B981]/20",
        headline: "Analytics for High-Growth E-Commerce",
        sub: "Track AOV, Conversion Rate, Inventory and benchmark your store.",
        kpis: ["AOV (Avg Order Value)", "Conversion Rate", "Stock Velocity", "Retail Benchmark"],
        command: "npm run theme:ecommerce",
    },
];

const FEATURES = [
    { icon: Zap, title: "Framer Motion Animations", desc: "Silky-smooth page transitions and micro-interactions out-of-the-box. Staggered entrances, cubic-bezier precision." },
    { icon: Layers, title: "Domain-Driven Layout", desc: "Bento-Box KPI grid, Radar chart, line charts — all isolated in reusable, typed React components." },
    { icon: RefreshCw, title: "One-Command Niche Switch", desc: "Run `npm run theme:saas` and the entire UI — colors, KPI labels, sidebar — morphs to match your industry." },
    { icon: Shield, title: "Zero External Dependencies", desc: "Only Next.js, Tailwind, Recharts, and Framer Motion. Plug your own API and ship in hours." },
    { icon: Code2, title: "Production-Ready Code", desc: "Fully typed TypeScript, isolated mock data engine, centralized config. Clean code = easier customization." },
    { icon: BarChart3, title: "Rich Data Visualizations", desc: "Line, Radar, and Bento-Box KPIs powered by Recharts. Integrated tooltips, custom ticks, animated data entry." },
];

const PRICING = [
    {
        name: "Personal License",
        price: "$149",
        period: "one-time",
        color: "border-white/[0.08]",
        btnClass: "bg-white/[0.06] text-white hover:bg-white/[0.1]",
        tag: null,
        features: [
            "All 3 Niche Configurations",
            "1 End Product / Project",
            "Lifetime Source Code Access",
            "Free Future Updates",
            "Commercial Use",
        ],
    },
    {
        name: "Agency License",
        price: "$499",
        period: "one-time",
        color: "border-[#EAC54F]/30 bg-[#EAC54F]/[0.03]",
        btnClass: "bg-[#EAC54F] text-[#09090B] hover:bg-yellow-300 font-bold",
        tag: "Most Popular",
        features: [
            "Everything in Personal",
            "Unlimited Client Projects",
            "Resell to Your Clients",
            "White-Label Ready",
            "Priority Email Support",
        ],
    },
];

export default function LandingPage() {
    const [activeNiche, setActiveNiche] = useState(0);
    const niche = NICHES[activeNiche];

    return (
        <div className="min-h-screen bg-[#09090B] text-white overflow-x-hidden relative">

            {/* Grid Background */}
            <div
                className="pointer-events-none fixed inset-0 opacity-[0.03]"
                style={{
                    backgroundImage: "linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)",
                    backgroundSize: "64px 64px",
                }}
            />

            {/* Glow Hero spot */}
            <div
                className="pointer-events-none fixed top-0 left-1/2 -translate-x-1/2 w-[900px] h-[500px] rounded-full opacity-20 blur-[120px] transition-colors duration-700"
                style={{ background: `radial-gradient(ellipse at center, ${niche.color}, transparent 70%)` }}
            />

            {/* ─── NAV ─── */}
            <nav className="relative z-20 flex items-center justify-between max-w-6xl mx-auto px-6 py-6">
                <div className="flex items-center gap-3">
                    <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm text-[#09090B] transition-colors duration-500"
                        style={{ background: niche.color }}
                    >
                        ORM
                    </div>
                    <span className="font-semibold tracking-tight">ORMpro</span>
                    <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase tracking-wider ${niche.badge}`}
                    >
                        Boilerplate
                    </span>
                </div>
                <div className="flex items-center gap-6">
                    <a href="#features" className="text-sm text-zinc-400 hover:text-white transition-colors hidden md:block">Features</a>
                    <a href="#pricing" className="text-sm text-zinc-400 hover:text-white transition-colors hidden md:block">Pricing</a>
                    <Link
                        href="/login"
                        className="flex items-center gap-2 text-sm font-semibold px-4 py-2 rounded-xl text-[#09090B] transition-all hover:scale-105"
                        style={{ background: niche.color }}
                    >
                        View Demo <ArrowRight size={14} />
                    </Link>
                </div>
            </nav>

            {/* ─── HERO ─── */}
            <section className="relative z-10 max-w-5xl mx-auto px-6 pt-24 pb-20 text-center">
                <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, ease }}
                >
                    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-white/[0.08] bg-white/[0.03] text-sm text-zinc-400 mb-8">
                        <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                        Next.js 14 · TypeScript · Framer Motion · Recharts
                    </div>

                    <h1 className="text-5xl sm:text-7xl font-bold tracking-tight leading-[1.05] mb-6">
                        Skip 100+ hours of<br />
                        <span
                            className="transition-colors duration-700"
                            style={{ color: niche.color }}
                        >
                            dashboard UI
                        </span>{" "}
                        design.
                    </h1>

                    <p className="text-lg text-zinc-400 max-w-2xl mx-auto mb-10 leading-relaxed">
                        A production-ready Next.js dashboard boilerplate with stunning animations and a one-command niche switch for <strong className="text-white">Hotel</strong>, <strong className="text-white">SaaS</strong>, and <strong className="text-white">E-Commerce</strong>.
                    </p>

                    <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                        <a
                            href="#pricing"
                            className="flex items-center gap-2 px-8 py-4 rounded-xl font-bold text-[#09090B] transition-all hover:scale-105 hover:brightness-110"
                            style={{ background: niche.color }}
                        >
                            Get the Template <ArrowRight size={16} />
                        </a>
                        <Link
                            href="/login"
                            className="flex items-center gap-2 px-8 py-4 rounded-xl font-semibold border border-white/[0.1] bg-white/[0.03] text-zinc-300 hover:bg-white/[0.06] hover:text-white transition-all"
                        >
                            <ExternalLink size={16} /> Live Demo
                        </Link>
                    </div>
                </motion.div>
            </section>

            {/* ─── NICHE SWITCHER ─── */}
            <section className="relative z-10 max-w-5xl mx-auto px-6 pb-28">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3, duration: 0.7, ease }}
                >
                    <div className="text-center mb-8">
                        <p className="text-[10px] uppercase font-semibold tracking-widest text-zinc-500 mb-3">
                            3 niches, one codebase — switch with a single command
                        </p>
                        <div className="flex flex-wrap justify-center gap-3">
                            {NICHES.map((n, i) => (
                                <button
                                    key={n.key}
                                    onClick={() => setActiveNiche(i)}
                                    className={`px-5 py-2.5 rounded-xl text-sm font-semibold border transition-all duration-300 ${activeNiche === i
                                            ? `border-transparent text-[#09090B]`
                                            : "border-white/[0.08] text-zinc-400 hover:text-white hover:border-white/20 bg-white/[0.02]"
                                        }`}
                                    style={activeNiche === i ? { background: n.color } : {}}
                                >
                                    {n.label}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Niche Card */}
                    <AnimatePresence mode="wait">
                        <motion.div
                            key={niche.key}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            transition={{ duration: 0.4, ease }}
                            className={`border rounded-2xl p-8 ring-1 ${niche.ring} ${niche.shadow} bg-white/[0.02]`}
                            style={{ borderColor: `${niche.color}30` }}
                        >
                            <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
                                <div className="flex-1">
                                    <h3 className="text-2xl font-bold text-white mb-2">{niche.headline}</h3>
                                    <p className="text-zinc-400 leading-relaxed mb-6">{niche.sub}</p>
                                    <div className="grid grid-cols-2 gap-3">
                                        {niche.kpis.map((kpi) => (
                                            <div key={kpi} className="flex items-center gap-2 text-sm">
                                                <CheckCircle size={14} style={{ color: niche.color }} />
                                                <span className="text-zinc-300">{kpi}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="shrink-0">
                                    <div className="bg-[#09090B] border border-white/[0.08] rounded-xl p-4 font-mono text-sm">
                                        <p className="text-zinc-500 mb-1 text-[10px] uppercase tracking-widest">activate niche</p>
                                        <p style={{ color: niche.color }}>{niche.command}</p>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    </AnimatePresence>
                </motion.div>
            </section>

            {/* ─── FEATURES ─── */}
            <section id="features" className="relative z-10 max-w-5xl mx-auto px-6 pb-28">
                <div className="text-center mb-14">
                    <p className="text-[10px] uppercase font-semibold tracking-widest text-zinc-500 mb-3">What's Inside</p>
                    <h2 className="text-4xl font-bold tracking-tight">Everything you need to ship fast.</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    {FEATURES.map((f, i) => (
                        <motion.div
                            key={f.title}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: i * 0.08, duration: 0.6, ease }}
                            className="group bg-white/[0.02] border border-white/[0.05] rounded-2xl p-6 hover:bg-white/[0.04] hover:border-white/[0.1] hover:-translate-y-1 transition-all duration-300"
                        >
                            <div
                                className="w-9 h-9 rounded-lg flex items-center justify-center mb-4 transition-colors duration-500"
                                style={{ background: `${niche.color}18`, color: niche.color }}
                            >
                                <f.icon size={18} />
                            </div>
                            <h3 className="font-semibold text-white mb-2">{f.title}</h3>
                            <p className="text-sm text-zinc-500 leading-relaxed">{f.desc}</p>
                        </motion.div>
                    ))}
                </div>
            </section>

            {/* ─── SOCIAL PROOF ─── */}
            <section className="relative z-10 max-w-5xl mx-auto px-6 pb-28">
                <div className="border border-white/[0.05] bg-white/[0.02] rounded-2xl p-8 text-center">
                    <div className="flex justify-center mb-3">
                        {[1, 2, 3, 4, 5].map((s) => (
                            <Star key={s} size={16} className="fill-[#EAC54F] text-[#EAC54F]" />
                        ))}
                    </div>
                    <blockquote className="text-lg text-zinc-200 italic max-w-xl mx-auto mb-4">
                        "The design quality is on par with Linear and Vercel's own dashboards. Saved us weeks of UI work."
                    </blockquote>
                    <p className="text-sm text-zinc-500">— A Developer</p>
                </div>
            </section>

            {/* ─── PRICING ─── */}
            <section id="pricing" className="relative z-10 max-w-5xl mx-auto px-6 pb-32">
                <div className="text-center mb-14">
                    <p className="text-[10px] uppercase font-semibold tracking-widest text-zinc-500 mb-3">Pricing</p>
                    <h2 className="text-4xl font-bold tracking-tight">One-time payment. Lifetime access.</h2>
                    <p className="text-zinc-400 mt-4">No subscriptions. No hidden fees. Get the code, ship your product.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
                    {PRICING.map((plan) => (
                        <motion.div
                            key={plan.name}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.6, ease }}
                            className={`relative border rounded-2xl p-8 flex flex-col ${plan.color}`}
                        >
                            {plan.tag && (
                                <div
                                    className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-[11px] font-bold text-[#09090B] uppercase tracking-widest"
                                    style={{ background: niche.color }}
                                >
                                    {plan.tag}
                                </div>
                            )}
                            <p className="text-sm font-semibold text-zinc-400 mb-1">{plan.name}</p>
                            <div className="flex items-baseline gap-2 mb-6">
                                <span className="text-5xl font-bold text-white">{plan.price}</span>
                                <span className="text-zinc-500 text-sm">{plan.period}</span>
                            </div>
                            <ul className="space-y-3 mb-8 flex-1">
                                {plan.features.map((feat) => (
                                    <li key={feat} className="flex items-center gap-3 text-sm text-zinc-300">
                                        <CheckCircle size={14} style={{ color: niche.color }} className="shrink-0" />
                                        {feat}
                                    </li>
                                ))}
                            </ul>
                            <a
                                href="https://gumroad.com"
                                target="_blank"
                                rel="noopener noreferrer"
                                className={`w-full py-3.5 rounded-xl text-center text-sm transition-all hover:scale-[1.02] ${plan.btnClass}`}
                            >
                                Buy Now — {plan.price}
                            </a>
                        </motion.div>
                    ))}
                </div>
            </section>

            {/* ─── FOOTER ─── */}
            <footer className="relative z-10 border-t border-white/[0.05] py-8 text-center text-sm text-zinc-600">
                <p>© 2026 ORMpro Boilerplate · Built with Next.js 14 + Tailwind CSS · All rights reserved.</p>
            </footer>
        </div>
    );
}
